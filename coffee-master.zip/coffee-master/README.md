# Smarter Coffee terminal client

This is an experimental terminal client for the [Smarter Coffee machine](http://smarter.am/coffee/) written by Simone 'evilsocket' Margaritelli, [more informations can be found here](https://www.evilsocket.net/2016/10/09/IoCOFFEE-Reversing-the-Smarter-Coffee-IoT-machine-protocol-to-make-coffee-using-terminal/).
